import express from 'express';
import { middleware, Client } from '@line/bot-sdk';
import dotenv from 'dotenv';
import { getHotels } from './services/rakuten.js';
import { enrichWithGoogleData } from './services/googlePlaces.js';
import { formatHotelFlexMessage } from './utils/messageFormatter.js';

dotenv.config();

const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
};

const app = express();
const client = new Client(config);

app.post('/webhook', middleware(config), async (req, res) => {
  Promise.all(req.body.events.map(handleEvent)).then((result) => res.json(result));
});

async function handleEvent(event) {
  if (event.type !== 'message' || event.message.type !== 'text') return;

  const userInput = event.message.text;
  const hotels = await getHotels(userInput);
  const enriched = await enrichWithGoogleData(hotels);
  const reply = formatHotelFlexMessage(enriched);

  return client.replyMessage(event.replyToken, reply);
}

app.listen(process.env.PORT || 3000);