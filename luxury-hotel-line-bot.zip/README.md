# Luxury Hotel LINE Bot 🏨
LINEで高級ホテルを提案するBotです。
楽天トラベルとGoogleレビューを活用しています。