// Google Places連携処理（後ほど実装）
export async function enrichWithGoogleData(hotels) { return hotels; }