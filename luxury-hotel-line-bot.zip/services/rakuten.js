// 楽天API連携処理（後ほど実装）
export async function getHotels(userInput) { return []; }