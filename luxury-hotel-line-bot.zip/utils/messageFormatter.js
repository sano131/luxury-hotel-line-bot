// LINE Flex Messageの整形（後ほど実装）
export function formatHotelFlexMessage(hotels) { return { type: 'text', text: 'ホテル情報です。' }; }